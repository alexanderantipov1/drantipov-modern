# Dr. Antipov - Oral Surgery Website

## Overview
A Next.js 14 website for Dr. Alexander Antipov, a board-certified oral surgeon in Northern California specializing in dental implants, full-arch restoration, and corrective jaw surgery.

## Multi-Step Consultation Form
The site includes a multi-step consultation form (matching fusiondentalimplants.com):
- **Form Component**: `src/components/forms/MultiStepConsultationForm.tsx`
- **Modal Wrapper**: `src/components/forms/ConsultationModal.tsx`
- **Backend Integration**: Submits to `https://api.fusiondentalimplants.com/api/v1/user-data` (centralized Salesforce integration)
- **Form Steps**: Assessment questions, personal info, address, payment options (including FICO), consultation readiness, optional appointment scheduling, confirmation
- **Marketing Attribution**: Captures UTM parameters, click IDs, device type, referral source via cookie-based tracking system
- **Cookie Tracking**: Session (`_fdi_sess`), marketing (`_fdi_mkt`), first-touch attribution (`_fdi_ft`), consent (`_fdi_consent`), client ID (`_fdi_cid`)
- **Cookie Consent**: GDPR-compliant banner with Accept All / Reject All options
- **Tracking Fields**: All sent as snake_case to match Salesforce API (utm_source, landing_page, device_type, etc.)

The "Book Consultation" and "Schedule Consultation" buttons throughout the site (Header, Hero, CTA sections) trigger the modal form.

## Project Structure
- `src/app/` - Next.js app router pages and layouts
- `src/components/` - React components
- `src/components/forms/` - Form components including consultation modal
- `src/constants/` - Application constants
- `src/lib/` - Utility libraries (cookies.ts, tracking.ts)
- `src/utils/` - Helper utilities
- `public/` - Static assets

## Tech Stack
- Next.js 14 (App Router)
- React 18
- TypeScript
- Tailwind CSS
- Radix UI components
- Framer Motion for animations
- React Hook Form + Zod for forms
- Resend for emails

## Development
Run the development server:
```bash
npm run dev
```
The app runs on port 5000.

## Deployment
Build for production:
```bash
npm run build
npm run start
```

## Configuration
- `next.config.mjs` - Next.js configuration
- `tailwind.config.ts` - Tailwind CSS configuration
- `tsconfig.json` - TypeScript configuration
- `components.json` - shadcn/ui component configuration
