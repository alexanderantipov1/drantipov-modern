import type { Metadata } from 'next'
import { Inter, Merriweather, Dancing_Script } from 'next/font/google'
import Script from 'next/script'
import { Header, Footer } from '@/components/layout'
import { GoogleAnalytics } from '@/components/analytics/GoogleAnalytics'
import { GoogleTagManager, GoogleTagManagerNoScript } from '@/components/analytics/GoogleTagManager'
import { TrackingProvider } from '@/components/TrackingProvider'
import { CookieConsent } from '@/components/CookieConsent'
import './globals.css'

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-sans',
  display: 'swap',
})

const merriweather = Merriweather({
  weight: ['300', '400', '700', '900'],
  subsets: ['latin'],
  variable: '--font-serif',
  display: 'swap',
})

const dancingScript = Dancing_Script({
  subsets: ['latin'],
  variable: '--font-signature',
  display: 'swap',
})

export const metadata: Metadata = {
  metadataBase: new URL('https://drantipov.com'),
  title: 'Dr. Alexander Antipov - Northern California\'s Premier Oral Surgeon',
  description: 'Board-certified oral surgeon Dr. Alexander Antipov specializes in dental implants, full-arch restoration, and corrective jaw surgery. Trusted by dentists across Northern California.',
  keywords: ['oral surgeon Northern California', 'dental implants Roseville', 'corrective jaw surgery Sacramento', 'full arch implants', 'board certified oral surgeon', 'Dr. Antipov'],
  openGraph: {
    title: 'Dr. Alexander Antipov - Northern California\'s Premier Oral Surgeon',
    description: 'Board-certified oral surgeon specializing in dental implants, full-arch restoration, and corrective jaw surgery.',
    url: 'https://drantipov.com',
    siteName: 'Dr. Alexander Antipov',
    images: [
      {
        url: '/images/drantipov.png',
        width: 1200,
        height: 1600,
        alt: 'Dr. Alexander Antipov - Board-Certified Oral & Maxillofacial Surgeon',
      },
    ],
    locale: 'en_US',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Dr. Alexander Antipov - Northern California\'s Premier Oral Surgeon',
    description: 'Board-certified oral surgeon specializing in dental implants, full-arch restoration, and corrective jaw surgery.',
    images: ['/images/drantipov.png'],
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`${inter.variable} ${merriweather.variable} ${dancingScript.variable}`}>
      <head>
        <GoogleAnalytics />
        <GoogleTagManager />
      </head>
      <body className="font-sans antialiased">
        <GoogleTagManagerNoScript />
        <Script
          src="https://www.google.com/recaptcha/api.js?render=6LfAv8grAAAAAFkd5EJ1HC4fbmTfdq3yce7rgPtg"
          strategy="afterInteractive"
        />
        <TrackingProvider>
          <Header />
          <main className="min-h-screen">
            {children}
          </main>
          <Footer />
          <CookieConsent />
        </TrackingProvider>
      </body>
    </html>
  )
}
