import { HeroSection } from "@/components/home/HeroSection"
import { YouTubeShortsSection } from "@/components/home/YouTubeShortsSection"
import { TestimonialsSection } from "@/components/home/TestimonialsSection"
import {
  AboutSection,
  ExpertiseSection,
  WhyChooseSection,
  CTASection,
  LatestInsightsSection,
} from "@/components/home"
import {
  getOrganizationSchema,
  getPhysicianSchema,
  structuredDataScript,
} from "@/lib/structured-data"

export default function Home() {
  // Combine Organization and Physician schemas for homepage
  const structuredData = [getOrganizationSchema(), getPhysicianSchema()]

  return (
    <>
      {/* Structured Data for SEO */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={structuredDataScript(structuredData)}
      />

      <HeroSection />
      <AboutSection />
      <YouTubeShortsSection />
      <TestimonialsSection />
      <LatestInsightsSection />
      <ExpertiseSection />
      <WhyChooseSection />
      <CTASection />
    </>
  )
}
