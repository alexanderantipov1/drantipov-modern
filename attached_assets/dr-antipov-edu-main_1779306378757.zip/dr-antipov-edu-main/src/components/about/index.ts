export { AboutPageHero } from "./AboutPageHero"
