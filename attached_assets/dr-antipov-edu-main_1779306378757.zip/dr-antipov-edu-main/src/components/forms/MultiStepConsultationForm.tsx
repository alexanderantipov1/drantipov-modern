"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Loader2, CheckCircle, ArrowRight, ArrowLeft, Calendar, Clock, MapPin, Phone } from "lucide-react"
import { cn } from "@/lib/utils"
import { useTracking } from "@/components/TrackingProvider"

declare global {
  interface Window {
    grecaptcha: {
      ready: (callback: () => void) => void
      execute: (siteKey: string, options: { action: string }) => Promise<string>
    }
  }
}

const RECAPTCHA_SITE_KEY = "6LfAv8grAAAAAFkd5EJ1HC4fbmTfdq3yce7rgPtg"

const US_STATES = [
  { value: "AL", label: "Alabama" },
  { value: "AK", label: "Alaska" },
  { value: "AZ", label: "Arizona" },
  { value: "AR", label: "Arkansas" },
  { value: "CA", label: "California" },
  { value: "CO", label: "Colorado" },
  { value: "CT", label: "Connecticut" },
  { value: "DE", label: "Delaware" },
  { value: "FL", label: "Florida" },
  { value: "GA", label: "Georgia" },
  { value: "HI", label: "Hawaii" },
  { value: "ID", label: "Idaho" },
  { value: "IL", label: "Illinois" },
  { value: "IN", label: "Indiana" },
  { value: "IA", label: "Iowa" },
  { value: "KS", label: "Kansas" },
  { value: "KY", label: "Kentucky" },
  { value: "LA", label: "Louisiana" },
  { value: "ME", label: "Maine" },
  { value: "MD", label: "Maryland" },
  { value: "MA", label: "Massachusetts" },
  { value: "MI", label: "Michigan" },
  { value: "MN", label: "Minnesota" },
  { value: "MS", label: "Mississippi" },
  { value: "MO", label: "Missouri" },
  { value: "MT", label: "Montana" },
  { value: "NE", label: "Nebraska" },
  { value: "NV", label: "Nevada" },
  { value: "NH", label: "New Hampshire" },
  { value: "NJ", label: "New Jersey" },
  { value: "NM", label: "New Mexico" },
  { value: "NY", label: "New York" },
  { value: "NC", label: "North Carolina" },
  { value: "ND", label: "North Dakota" },
  { value: "OH", label: "Ohio" },
  { value: "OK", label: "Oklahoma" },
  { value: "OR", label: "Oregon" },
  { value: "PA", label: "Pennsylvania" },
  { value: "RI", label: "Rhode Island" },
  { value: "SC", label: "South Carolina" },
  { value: "SD", label: "South Dakota" },
  { value: "TN", label: "Tennessee" },
  { value: "TX", label: "Texas" },
  { value: "UT", label: "Utah" },
  { value: "VT", label: "Vermont" },
  { value: "VA", label: "Virginia" },
  { value: "WA", label: "Washington" },
  { value: "WV", label: "West Virginia" },
  { value: "WI", label: "Wisconsin" },
  { value: "WY", label: "Wyoming" },
]

const TIME_SLOTS = [
  "8:00 AM", "8:30 AM", "9:00 AM", "9:30 AM", "10:00 AM", "10:30 AM",
  "11:00 AM", "11:30 AM", "12:00 PM", "12:30 PM", "1:00 PM", "1:30 PM",
  "2:00 PM", "2:30 PM", "3:00 PM", "3:30 PM", "4:00 PM", "4:30 PM"
]

interface FormData {
  currentSituation: string[]
  currentTreatments: string[]
  firstName: string
  lastName: string
  dob: string
  email: string
  phone: string
  street: string
  aptSuite: string
  city: string
  state: string
  zipCode: string
  paymentPlan: string
  ficoScore: string
  consultationReadiness: string
  assignedCenter: string
  appointmentDate: string
  appointmentTime: string
}

interface MultiStepConsultationFormProps {
  onClose?: () => void
}

export function MultiStepConsultationForm({ onClose }: MultiStepConsultationFormProps) {
  const [currentScreen, setCurrentScreen] = useState(0)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitStatus, setSubmitStatus] = useState<"idle" | "success" | "error">("idle")
  const [submitErrorMessage, setSubmitErrorMessage] = useState("")
  const [errors, setErrors] = useState<Record<string, string>>({})
  const { getTrackingData } = useTracking()

  const [formData, setFormData] = useState<FormData>({
    currentSituation: [],
    currentTreatments: [],
    firstName: "",
    lastName: "",
    dob: "",
    email: "",
    phone: "",
    street: "",
    aptSuite: "",
    city: "",
    state: "",
    zipCode: "",
    paymentPlan: "",
    ficoScore: "",
    consultationReadiness: "",
    assignedCenter: "",
    appointmentDate: "",
    appointmentTime: "",
  })

  const totalSteps = formData.consultationReadiness === "yes" ? 6 : 5

  const getProgressPercentage = () => {
    const stepMap: Record<number, number> = {
      0: 1, 1: 2, 2: 3, 3: 4, 4: 5, 6: 6
    }
    const step = stepMap[currentScreen]
    if (!step || currentScreen === 5 || currentScreen === 7) return 100
    return (step / totalSteps) * 100
  }

  const updateField = (field: keyof FormData, value: string | string[]) => {
    setFormData(prev => ({ ...prev, [field]: value }))
    setErrors(prev => ({ ...prev, [field]: "" }))
  }

  const toggleCheckbox = (field: "currentSituation" | "currentTreatments", value: string) => {
    setFormData(prev => {
      const current = prev[field]
      const updated = current.includes(value)
        ? current.filter(v => v !== value)
        : [...current, value]
      return { ...prev, [field]: updated }
    })
    setErrors(prev => ({ ...prev, [field]: "" }))
  }

  const formatDobInput = (value: string) => {
    const digits = value.replace(/\D/g, "").substring(0, 8)
    if (digits.length <= 2) return digits
    if (digits.length <= 4) return `${digits.substring(0, 2)}/${digits.substring(2)}`
    return `${digits.substring(0, 2)}/${digits.substring(2, 4)}/${digits.substring(4)}`
  }

  const validateScreen = (screen: number): boolean => {
    const newErrors: Record<string, string> = {}

    switch (screen) {
      case 0:
        if (formData.currentSituation.length === 0) {
          newErrors.currentSituation = "Please select at least one option"
        }
        if (formData.currentTreatments.length === 0) {
          newErrors.currentTreatments = "Please select at least one option"
        }
        break
      case 1:
        if (!formData.firstName.trim()) newErrors.firstName = "First name is required"
        if (!formData.lastName.trim()) newErrors.lastName = "Last name is required"
        if (!formData.dob.trim()) {
          newErrors.dob = "Date of birth is required"
        } else if (!/^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/(19|20)\d{2}$/.test(formData.dob)) {
          newErrors.dob = "Please enter a valid date in MM/DD/YYYY format"
        }
        if (!formData.email.trim()) {
          newErrors.email = "Email is required"
        } else if (!/^[a-zA-Z0-9._+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(formData.email)) {
          newErrors.email = "Please enter a valid email address"
        }
        if (!formData.phone.trim()) {
          newErrors.phone = "Phone is required"
        } else {
          const phoneDigits = formData.phone.replace(/\D/g, "")
          if (!/^(\+?1)?[2-9]\d{9}$/.test(phoneDigits)) {
            newErrors.phone = "Please enter a valid US phone number"
          }
        }
        break
      case 2:
        if (!formData.street.trim()) newErrors.street = "Street address is required"
        if (!formData.city.trim()) newErrors.city = "City is required"
        if (!formData.state) newErrors.state = "State is required"
        if (!formData.zipCode.trim()) newErrors.zipCode = "ZIP code is required"
        break
      case 3:
        if (!formData.paymentPlan) newErrors.paymentPlan = "Please select a payment option"
        if (formData.paymentPlan === "yes" && !formData.ficoScore) {
          newErrors.ficoScore = "Please select your FICO score range"
        }
        break
      case 4:
        if (!formData.consultationReadiness) {
          newErrors.consultationReadiness = "Please select an option"
        }
        break
      case 6:
        if (!formData.assignedCenter) newErrors.assignedCenter = "Please select a location"
        if (!formData.appointmentDate) newErrors.appointmentDate = "Please select a date"
        if (!formData.appointmentTime) newErrors.appointmentTime = "Please select a time"
        break
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const nextScreen = () => {
    if (!validateScreen(currentScreen)) return

    if (currentScreen === 4) {
      if (formData.consultationReadiness === "no") {
        submitForm()
        setCurrentScreen(5)
      } else {
        setCurrentScreen(6)
      }
    } else if (currentScreen < 7) {
      setCurrentScreen(currentScreen + 1)
    }
  }

  const prevScreen = () => {
    if (currentScreen === 6) {
      setCurrentScreen(4)
    } else if (currentScreen > 0) {
      setCurrentScreen(currentScreen - 1)
    }
  }

  const getDeviceType = () => {
    const userAgent = navigator.userAgent.toLowerCase()
    const isMobile = /mobile|android|iphone|ipad|ipod|blackberry|iemobile|opera mini/i.test(userAgent)
    const isTablet = /ipad|android(?!.*mobile)|tablet/i.test(userAgent)
    if (isTablet) return "Tablet"
    if (isMobile) return "Mobile"
    return "Desktop"
  }

  const getUrlParams = () => {
    if (typeof window === "undefined") return {}
    const urlSearchParams = new URLSearchParams(window.location.search)
    const params: Record<string, string> = {}
    const trackingKeys = [
      "utm_source", "utm_medium", "utm_campaign", "utm_term",
      "utm_content", "utm_id", "utm_location", "utm_adgroup",
      "utm_creative", "gclid", "fbclid",
    ]
    trackingKeys.forEach((key) => {
      const value = urlSearchParams.get(key)
      if (value) params[key] = value
    })
    return params
  }

  const formatDateForBackend = (dateString: string) => {
    if (!dateString) return ""
    const parts = dateString.split("/")
    if (parts.length === 3 && parts[0] && parts[1] && parts[2]) {
      const month = parts[0].padStart(2, "0")
      const day = parts[1].padStart(2, "0")
      const year = parts[2]
      return `${year}-${month}-${day}`
    }
    return dateString
  }

  const generateRecaptchaToken = (): Promise<string> => {
    return new Promise((resolve) => {
      if (typeof window.grecaptcha === "undefined") {
        resolve("")
        return
      }
      window.grecaptcha.ready(() => {
        window.grecaptcha
          .execute(RECAPTCHA_SITE_KEY, { action: "form_submit" })
          .then(resolve)
          .catch(() => resolve(""))
      })
    })
  }

  const submitForm = async () => {
    setIsSubmitting(true)
    setSubmitStatus("idle")
    setSubmitErrorMessage("")

    try {
      const recaptchaToken = await generateRecaptchaToken()
      const urlParams = getUrlParams()
      const trackingData = getTrackingData()

      const backendData = {
        firstName: formData.firstName,
        lastName: formData.lastName,
        dob: formatDateForBackend(formData.dob),
        email: formData.email,
        phone: formData.phone,
        streetAddress: formData.street,
        addressLine2: formData.aptSuite,
        city: formData.city,
        state: formData.state,
        zip: formData.zipCode,
        paymentOptions: formData.paymentPlan === "yes",
        ficoScore: formData.ficoScore,
        damagedTeeth: formData.currentSituation.includes("damagedTeeth"),
        missingTeeth: formData.currentSituation.includes("missingTeeth"),
        gumDisease: formData.currentSituation.includes("gumDisease"),
        currentSmileNone: formData.currentSituation.includes("noneApply"),
        currentSolutionsNone: formData.currentTreatments.includes("none"),
        currentSolutionsImplants: formData.currentTreatments.includes("implants"),
        currentSolutionsBridgesCrowns: formData.currentTreatments.includes("bridgesCrowns"),
        currentSolutionsDentures: formData.currentTreatments.includes("dentures"),
        businessUnit: "Fusion Dental Implants",
        recaptchaToken,
        ...(formData.appointmentDate && formData.appointmentTime ? {
          appointmentDate: formData.appointmentDate,
          appointmentTime: formData.appointmentTime,
          assignedCenter: formData.assignedCenter,
        } : {}),
        ...trackingData,
        ...urlParams,
      }

      const response = await fetch("/api/submit-consultation", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(backendData),
      })

      const responseData = await response.json().catch(() => null)

      if (response.ok && responseData?.success !== false) {
        setSubmitStatus("success")
        if (formData.appointmentDate && formData.appointmentTime) {
          setCurrentScreen(7)
        }
      } else {
        const msg = responseData?.message || "Submission failed"
        setSubmitErrorMessage(msg)
        throw new Error(msg)
      }
    } catch (error) {
      setSubmitStatus("error")
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleFinalSubmit = () => {
    if (!validateScreen(6)) return
    submitForm()
  }

  const getMinDate = () => {
    const tomorrow = new Date()
    tomorrow.setDate(tomorrow.getDate() + 1)
    return tomorrow.toISOString().split("T")[0]
  }

  const CheckboxOption = ({ 
    field, 
    value, 
    label 
  }: { 
    field: "currentSituation" | "currentTreatments"
    value: string
    label: string 
  }) => (
    <button
      type="button"
      onClick={() => toggleCheckbox(field, value)}
      className={cn(
        "w-full p-4 text-left rounded-lg border-2 transition-all",
        formData[field].includes(value)
          ? "border-primary-600 bg-primary-50"
          : "border-neutral-200 hover:border-neutral-300"
      )}
    >
      <div className="flex items-center gap-3">
        <div className={cn(
          "w-5 h-5 rounded border-2 flex items-center justify-center",
          formData[field].includes(value)
            ? "border-primary-600 bg-primary-600"
            : "border-neutral-300"
        )}>
          {formData[field].includes(value) && (
            <CheckCircle className="w-4 h-4 text-white" />
          )}
        </div>
        <span className="text-neutral-700">{label}</span>
      </div>
    </button>
  )

  const RadioOption = ({ 
    field, 
    value, 
    label 
  }: { 
    field: keyof FormData
    value: string
    label: string 
  }) => (
    <button
      type="button"
      onClick={() => updateField(field, value)}
      className={cn(
        "w-full p-4 text-left rounded-lg border-2 transition-all",
        formData[field] === value
          ? "border-primary-600 bg-primary-50"
          : "border-neutral-200 hover:border-neutral-300"
      )}
    >
      <div className="flex items-center gap-3">
        <div className={cn(
          "w-5 h-5 rounded-full border-2 flex items-center justify-center",
          formData[field] === value
            ? "border-primary-600"
            : "border-neutral-300"
        )}>
          {formData[field] === value && (
            <div className="w-3 h-3 rounded-full bg-primary-600" />
          )}
        </div>
        <span className="text-neutral-700">{label}</span>
      </div>
    </button>
  )

  return (
    <div className="max-h-[80vh] overflow-y-auto">
      {currentScreen !== 5 && currentScreen !== 7 && (
        <div className="mb-6">
          <div className="h-2 bg-neutral-200 rounded-full overflow-hidden">
            <div
              className="h-full bg-primary-600 transition-all duration-300"
              style={{ width: `${getProgressPercentage()}%` }}
            />
          </div>
          <p className="text-sm text-neutral-500 mt-2 text-center">
            Step {currentScreen < 5 ? currentScreen + 1 : currentScreen === 6 ? 6 : currentScreen + 1} of {totalSteps}
          </p>
        </div>
      )}

      {currentScreen === 0 && (
        <div className="space-y-6">
          <h2 className="text-2xl font-semibold text-neutral-900 text-center">Assessment Questions</h2>
          
          <div className="space-y-4">
            <div>
              <Label className="text-base font-medium">Tell us about your current smile.</Label>
              <p className="text-sm text-neutral-500 mb-3">Select all that apply</p>
              <div className="space-y-2">
                <CheckboxOption field="currentSituation" value="missingTeeth" label="I have missing teeth" />
                <CheckboxOption field="currentSituation" value="damagedTeeth" label="My teeth are cracked, loose or failing" />
                <CheckboxOption field="currentSituation" value="gumDisease" label="I have gum or infection problems" />
                <CheckboxOption field="currentSituation" value="noneApply" label="None of the above" />
              </div>
              {errors.currentSituation && (
                <p className="text-sm text-red-500 mt-2">{errors.currentSituation}</p>
              )}
            </div>

            <div>
              <Label className="text-base font-medium">What solutions do you currently use?</Label>
              <p className="text-sm text-neutral-500 mb-3">Select all that apply</p>
              <div className="space-y-2">
                <CheckboxOption field="currentTreatments" value="dentures" label="Dentures or Partials" />
                <CheckboxOption field="currentTreatments" value="bridgesCrowns" label="Bridges or crowns" />
                <CheckboxOption field="currentTreatments" value="implants" label="Dental Implants already in place" />
                <CheckboxOption field="currentTreatments" value="none" label="None of the above" />
              </div>
              {errors.currentTreatments && (
                <p className="text-sm text-red-500 mt-2">{errors.currentTreatments}</p>
              )}
            </div>
          </div>

          <div className="flex justify-end">
            <Button onClick={nextScreen} size="lg">
              Next <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>
      )}

      {currentScreen === 1 && (
        <div className="space-y-6">
          <h2 className="text-2xl font-semibold text-neutral-900 text-center">Personal Information</h2>
          
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="firstName">First Name *</Label>
                <Input
                  id="firstName"
                  value={formData.firstName}
                  onChange={(e) => updateField("firstName", e.target.value)}
                  className={errors.firstName ? "border-red-500" : ""}
                />
                {errors.firstName && <p className="text-sm text-red-500 mt-1">{errors.firstName}</p>}
              </div>
              <div>
                <Label htmlFor="lastName">Last Name *</Label>
                <Input
                  id="lastName"
                  value={formData.lastName}
                  onChange={(e) => updateField("lastName", e.target.value)}
                  className={errors.lastName ? "border-red-500" : ""}
                />
                {errors.lastName && <p className="text-sm text-red-500 mt-1">{errors.lastName}</p>}
              </div>
            </div>

            <div>
              <Label htmlFor="dob">Date of Birth *</Label>
              <Input
                id="dob"
                placeholder="MM/DD/YYYY"
                value={formData.dob}
                onChange={(e) => updateField("dob", formatDobInput(e.target.value))}
                className={errors.dob ? "border-red-500" : ""}
              />
              {errors.dob && <p className="text-sm text-red-500 mt-1">{errors.dob}</p>}
            </div>

            <div>
              <Label htmlFor="email">Email *</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => updateField("email", e.target.value)}
                className={errors.email ? "border-red-500" : ""}
              />
              {errors.email && <p className="text-sm text-red-500 mt-1">{errors.email}</p>}
            </div>

            <div>
              <Label htmlFor="phone">Phone *</Label>
              <Input
                id="phone"
                type="tel"
                value={formData.phone}
                onChange={(e) => updateField("phone", e.target.value)}
                className={errors.phone ? "border-red-500" : ""}
              />
              {errors.phone && <p className="text-sm text-red-500 mt-1">{errors.phone}</p>}
            </div>
          </div>

          <div className="flex justify-between">
            <Button variant="outline" onClick={prevScreen} size="lg">
              <ArrowLeft className="mr-2 h-4 w-4" /> Previous
            </Button>
            <Button onClick={nextScreen} size="lg">
              Next <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>
      )}

      {currentScreen === 2 && (
        <div className="space-y-6">
          <h2 className="text-2xl font-semibold text-neutral-900 text-center">Address Information</h2>
          
          <div className="space-y-4">
            <div>
              <Label htmlFor="street">Street Address *</Label>
              <Input
                id="street"
                value={formData.street}
                onChange={(e) => updateField("street", e.target.value)}
                className={errors.street ? "border-red-500" : ""}
              />
              {errors.street && <p className="text-sm text-red-500 mt-1">{errors.street}</p>}
            </div>

            <div>
              <Label htmlFor="aptSuite">Unit / Suite</Label>
              <Input
                id="aptSuite"
                value={formData.aptSuite}
                onChange={(e) => updateField("aptSuite", e.target.value)}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="city">City *</Label>
                <Input
                  id="city"
                  value={formData.city}
                  onChange={(e) => updateField("city", e.target.value)}
                  className={errors.city ? "border-red-500" : ""}
                />
                {errors.city && <p className="text-sm text-red-500 mt-1">{errors.city}</p>}
              </div>
              <div>
                <Label htmlFor="state">State *</Label>
                <Select value={formData.state} onValueChange={(value) => updateField("state", value)}>
                  <SelectTrigger className={errors.state ? "border-red-500" : ""}>
                    <SelectValue placeholder="Select State" />
                  </SelectTrigger>
                  <SelectContent>
                    {US_STATES.map((state) => (
                      <SelectItem key={state.value} value={state.value}>
                        {state.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {errors.state && <p className="text-sm text-red-500 mt-1">{errors.state}</p>}
              </div>
            </div>

            <div className="w-1/2">
              <Label htmlFor="zipCode">ZIP Code *</Label>
              <Input
                id="zipCode"
                value={formData.zipCode}
                onChange={(e) => updateField("zipCode", e.target.value)}
                className={errors.zipCode ? "border-red-500" : ""}
              />
              {errors.zipCode && <p className="text-sm text-red-500 mt-1">{errors.zipCode}</p>}
            </div>
          </div>

          <div className="flex justify-between">
            <Button variant="outline" onClick={prevScreen} size="lg">
              <ArrowLeft className="mr-2 h-4 w-4" /> Previous
            </Button>
            <Button onClick={nextScreen} size="lg">
              Next <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>
      )}

      {currentScreen === 3 && (
        <div className="space-y-6">
          <h2 className="text-2xl font-semibold text-neutral-900 text-center">Payment Options</h2>
          
          <div className="space-y-4">
            <div>
              <Label className="text-base font-medium">Would you like to explore affordable payment options?</Label>
              <div className="space-y-2 mt-3">
                <RadioOption field="paymentPlan" value="no" label="I am able to pay for the treatment upfront" />
                <RadioOption field="paymentPlan" value="yes" label="Yes, I would like to explore flexible payment options" />
              </div>
              {errors.paymentPlan && <p className="text-sm text-red-500 mt-2">{errors.paymentPlan}</p>}
            </div>

            {formData.paymentPlan === "yes" && (
              <div>
                <Label className="text-base font-medium">What is your approximate FICO score? *</Label>
                <div className="space-y-2 mt-3">
                  <RadioOption field="ficoScore" value="740+" label="740+" />
                  <RadioOption field="ficoScore" value="700-739" label="700-739" />
                  <RadioOption field="ficoScore" value="660-699" label="660-699" />
                  <RadioOption field="ficoScore" value="Below 660" label="Below 660" />
                </div>
                {errors.ficoScore && <p className="text-sm text-red-500 mt-2">{errors.ficoScore}</p>}
              </div>
            )}
          </div>

          <div className="flex justify-between">
            <Button variant="outline" onClick={prevScreen} size="lg">
              <ArrowLeft className="mr-2 h-4 w-4" /> Previous
            </Button>
            <Button onClick={nextScreen} size="lg">
              Next <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>
      )}

      {currentScreen === 4 && (
        <div className="space-y-6">
          <h2 className="text-2xl font-semibold text-neutral-900 text-center">Schedule Your Free Consultation</h2>
          
          <div className="space-y-4">
            <div>
              <Label className="text-base font-medium">Are you ready to book a free consultation appointment now?</Label>
              <div className="space-y-2 mt-3">
                <RadioOption field="consultationReadiness" value="yes" label="Yes, I am ready" />
                <RadioOption field="consultationReadiness" value="no" label="I would like more information first" />
              </div>
              {errors.consultationReadiness && <p className="text-sm text-red-500 mt-2">{errors.consultationReadiness}</p>}
            </div>
          </div>

          <div className="flex justify-between">
            <Button variant="outline" onClick={prevScreen} size="lg">
              <ArrowLeft className="mr-2 h-4 w-4" /> Previous
            </Button>
            <Button onClick={nextScreen} size="lg" disabled={isSubmitting}>
              {isSubmitting ? (
                <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Submitting...</>
              ) : formData.consultationReadiness === "no" ? (
                <>Finish <CheckCircle className="ml-2 h-4 w-4" /></>
              ) : (
                <>Next <ArrowRight className="ml-2 h-4 w-4" /></>
              )}
            </Button>
          </div>
        </div>
      )}

      {currentScreen === 5 && (
        <div className="space-y-6 text-center py-8">
          <CheckCircle className="w-16 h-16 text-green-500 mx-auto" />
          <h2 className="text-2xl font-semibold text-neutral-900">We'll Be In Touch</h2>
          <p className="text-neutral-600">
            Thank you for your interest in Dr. Antipov's practice!<br /><br />
            An appointment coordinator will contact you within 1 hour to discuss your options and provide personalized information about our services.
          </p>
          <div className="bg-neutral-50 rounded-lg p-4">
            <div className="flex items-center justify-center gap-2 text-neutral-700">
              <Phone className="h-5 w-5 text-primary-600" />
              <span>Questions? Call us at</span>
              <a href="tel:+19167909693" className="text-primary-600 font-medium hover:underline">(916) 790-9693</a>
            </div>
          </div>
          {onClose && (
            <Button onClick={onClose} size="lg">Done</Button>
          )}
        </div>
      )}

      {currentScreen === 6 && (
        <div className="space-y-6">
          <h2 className="text-2xl font-semibold text-neutral-900 text-center">Schedule Your Appointment</h2>
          
          <div className="space-y-4">
            <div>
              <Label className="text-base font-medium">Select Location *</Label>
              <div className="space-y-2 mt-3">
                <RadioOption field="assignedCenter" value="Roseville" label="Roseville" />
                <RadioOption field="assignedCenter" value="El Dorado Hills" label="El Dorado Hills" />
              </div>
              {errors.assignedCenter && <p className="text-sm text-red-500 mt-2">{errors.assignedCenter}</p>}
            </div>

            <div>
              <Label htmlFor="appointmentDate">Select Date *</Label>
              <Input
                id="appointmentDate"
                type="date"
                min={getMinDate()}
                value={formData.appointmentDate}
                onChange={(e) => updateField("appointmentDate", e.target.value)}
                className={errors.appointmentDate ? "border-red-500" : ""}
              />
              {errors.appointmentDate && <p className="text-sm text-red-500 mt-1">{errors.appointmentDate}</p>}
            </div>

            <div>
              <Label className="text-base font-medium">Select Time *</Label>
              {!formData.appointmentDate ? (
                <div className="bg-neutral-50 rounded-lg p-6 text-center text-neutral-500">
                  <Clock className="h-8 w-8 mx-auto mb-2 opacity-50" />
                  <p>Please select a date first</p>
                </div>
              ) : (
                <div className="grid grid-cols-3 gap-2 mt-3">
                  {TIME_SLOTS.map((time) => (
                    <button
                      key={time}
                      type="button"
                      onClick={() => updateField("appointmentTime", time)}
                      className={cn(
                        "p-3 text-sm rounded-lg border-2 transition-all",
                        formData.appointmentTime === time
                          ? "border-primary-600 bg-primary-50 text-primary-700"
                          : "border-neutral-200 hover:border-neutral-300"
                      )}
                    >
                      {time}
                    </button>
                  ))}
                </div>
              )}
              {errors.appointmentTime && <p className="text-sm text-red-500 mt-2">{errors.appointmentTime}</p>}
            </div>
          </div>

          <div className="flex justify-between">
            <Button variant="outline" onClick={prevScreen} size="lg">
              <ArrowLeft className="mr-2 h-4 w-4" /> Previous
            </Button>
            <Button onClick={handleFinalSubmit} size="lg" disabled={isSubmitting}>
              {isSubmitting ? (
                <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Booking...</>
              ) : (
                "Book Now"
              )}
            </Button>
          </div>
        </div>
      )}

      {currentScreen === 7 && (
        <div className="space-y-6 py-4">
          <div className="text-center">
            <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
            <h2 className="text-2xl font-semibold text-neutral-900">Booking Confirmed!</h2>
          </div>

          <div className="bg-primary-50 rounded-lg p-6 space-y-4">
            <h3 className="font-semibold text-neutral-900 flex items-center gap-2">
              <Calendar className="h-5 w-5 text-primary-600" />
              Your Appointment Details
            </h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-neutral-600">Location:</span>
                <span className="font-medium">{formData.assignedCenter}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-600">Date:</span>
                <span className="font-medium">{formData.appointmentDate}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-600">Time:</span>
                <span className="font-medium">{formData.appointmentTime}</span>
              </div>
            </div>
          </div>

          <div className="bg-neutral-50 rounded-lg p-6 space-y-3">
            <h3 className="font-semibold text-neutral-900">What to Expect</h3>
            <ul className="text-sm text-neutral-600 space-y-2">
              <li><strong>Booking Confirmation:</strong> One of our appointment coordinators will reach out shortly to confirm your appointment</li>
              <li><strong>Arrival:</strong> Please arrive 15 minutes early to complete any remaining paperwork</li>
              <li><strong>Consultation:</strong> We'll review your dental history and discuss your treatment goals</li>
              <li><strong>Examination:</strong> A comprehensive oral examination will be performed</li>
              <li><strong>Treatment Plan:</strong> We'll create a personalized treatment plan tailored to your needs</li>
            </ul>
          </div>

          {onClose && (
            <div className="text-center">
              <Button onClick={onClose} size="lg">Done</Button>
            </div>
          )}
        </div>
      )}

      {submitStatus === "error" && currentScreen !== 5 && currentScreen !== 7 && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 mt-4">
          <p className="text-red-700 text-sm">
            {submitErrorMessage || "Submission failed."} Please try again or call us at (916) 790-9693 for assistance.
          </p>
        </div>
      )}
    </div>
  )
}
