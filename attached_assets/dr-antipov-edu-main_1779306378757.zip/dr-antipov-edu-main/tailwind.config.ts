import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: ["class"],
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
  	extend: {
  		colors: {
  			border: 'hsl(var(--border))',
  			input: 'hsl(var(--input))',
  			ring: 'hsl(var(--ring))',
  			background: 'hsl(var(--background))',
  			foreground: 'hsl(var(--foreground))',
  			primary: {
  				'50': '#e8f0f5',
  				'100': '#d1e1eb',
  				'200': '#a3c3d7',
  				'300': '#75a5c3',
  				'400': '#4787af',
  				'500': '#0e3e5e',
  				'600': '#0b324b',
  				'700': '#082538',
  				'800': '#061926',
  				'900': '#030c13',
  				DEFAULT: 'hsl(var(--primary))',
  				foreground: 'hsl(var(--primary-foreground))'
  			},
  			secondary: {
  				DEFAULT: 'hsl(var(--secondary))',
  				foreground: 'hsl(var(--secondary-foreground))'
  			},
  			destructive: {
  				DEFAULT: 'hsl(var(--destructive))',
  				foreground: 'hsl(var(--destructive-foreground))'
  			},
  			muted: {
  				DEFAULT: 'hsl(var(--muted))',
  				foreground: 'hsl(var(--muted-foreground))'
  			},
  			accent: {
  				'50': '#f3f3f3',
  				'100': '#e7e7e8',
  				'200': '#cfcfd1',
  				'300': '#b7b7ba',
  				'400': '#9f9fa3',
  				'500': '#444346',
  				'600': '#363538',
  				'700': '#28282a',
  				'800': '#1a1a1c',
  				'900': '#0d0d0e',
  				DEFAULT: 'hsl(var(--accent))',
  				foreground: 'hsl(var(--accent-foreground))'
  			},
  			popover: {
  				DEFAULT: 'hsl(var(--popover))',
  				foreground: 'hsl(var(--popover-foreground))'
  			},
  			card: {
  				DEFAULT: 'hsl(var(--card))',
  				foreground: 'hsl(var(--card-foreground))'
  			},
  			neutral: {
  				'50': '#f5f5f5',
  				'100': '#e5e5e5',
  				'200': '#cccccc',
  				'300': '#b2b2b2',
  				'400': '#999999',
  				'500': '#444346',
  				'600': '#333333',
  				'700': '#1a1a1a',
  				'800': '#0d0d0d',
  				'900': '#000000'
  			}
  		},
  		fontFamily: {
  			sans: [
  				'var(--font-sans)',
  				'system-ui',
  				'sans-serif'
  			],
  			serif: [
  				'var(--font-serif)',
  				'Georgia',
  				'serif'
  			],
  			signature: [
  				'var(--font-signature)',
  				'cursive'
  			]
  		},
  		borderRadius: {
  			lg: '12px',
  			xl: '16px',
  			'2xl': '24px'
  		},
  		boxShadow: {
  			glass: '0 8px 32px 0 rgba(14, 62, 94, 0.15)',
  			'glass-lg': '0 12px 48px 0 rgba(14, 62, 94, 0.20)'
  		},
  		backdropBlur: {
  			xs: '2px'
  		},
  		spacing: {
  			'18': '4.5rem',
  			'112': '28rem',
  			'128': '32rem'
  		},
  		keyframes: {
  			'accordion-down': {
  				from: {
  					height: '0'
  				},
  				to: {
  					height: 'var(--radix-accordion-content-height)'
  				}
  			},
  			'accordion-up': {
  				from: {
  					height: 'var(--radix-accordion-content-height)'
  				},
  				to: {
  					height: '0'
  				}
  			}
  		},
  		animation: {
  			'accordion-down': 'accordion-down 0.2s ease-out',
  			'accordion-up': 'accordion-up 0.2s ease-out'
  		}
  	}
  },
  plugins: [require("tailwindcss-animate")],
};

export default config;
