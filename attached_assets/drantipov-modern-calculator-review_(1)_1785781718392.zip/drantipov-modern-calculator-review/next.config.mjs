import { fileURLToPath } from 'node:url'
import { dirname } from 'node:path'

const __dirname = dirname(fileURLToPath(import.meta.url))

const isDev = process.env.NODE_ENV === 'development'

// Same CSP as production, trimmed to the third parties these two pages use:
// DentalPrice (calculator API + widget), AI Smile (smile.dentalprice.ai),
// Google reCAPTCHA and Google Fonts.
const csp = [
  "default-src 'self'",
  `script-src 'self' 'unsafe-inline'${isDev ? " 'unsafe-eval'" : ""} https://www.google.com/recaptcha/ https://www.gstatic.com/recaptcha/ https://smile.dentalprice.ai https://widget.dentalprice.ai`,
  "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
  "font-src 'self' data: https://fonts.gstatic.com",
  "img-src 'self' data: blob: https://smile.dentalprice.ai https://widget.dentalprice.ai",
  "connect-src 'self' https://smile.dentalprice.ai https://widget.dentalprice.ai https://api.dentalprice.ai",
  "frame-src 'self' https://smile.dentalprice.ai https://widget.dentalprice.ai https://www.google.com/recaptcha/",
  "media-src 'self' blob:",
  "worker-src 'self' blob:",
  "object-src 'none'",
  "base-uri 'self'",
  "form-action 'self'",
  "frame-ancestors 'self'",
  "upgrade-insecure-requests",
].join('; ')

/** @type {import('next').NextConfig} */
const nextConfig = {
  turbopack: { root: __dirname },
  images: {
    // Demo build: skip the server-side optimizer entirely (needs `sharp` +
    // a matching Node ABI). Avoids "isn't a valid image, received null"
    // failures on machines where that optional dependency isn't installed.
    unoptimized: true,
  },
  async headers() {
    return [
      {
        source: '/(.*)',
        headers: [
          { key: 'Content-Security-Policy', value: csp },
          { key: 'X-Content-Type-Options', value: 'nosniff' },
          { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
          // AI Smile Preview needs the camera; allow it for self + the widget origin.
          { key: 'Permissions-Policy', value: 'camera=(self "https://smile.dentalprice.ai"), microphone=(), geolocation=()' },
        ],
      },
    ]
  },
}

export default nextConfig
