import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Not part of this demo build",
  robots: { index: false, follow: false },
};

/**
 * Catch-all placeholder. This review build only ships the calculator and
 * AI Smile Preview pages, but the real site header/footer are kept intact for
 * visual fidelity - so their links land here instead of a 404.
 */
export default async function NotInDemo({
  params,
}: {
  params: Promise<{ slug?: string[] }>;
}) {
  const { slug } = await params;
  const segments = slug ?? [];
  const path = "/" + segments.join("/");

  // Never swallow missing static assets. Without this, a request for a file
  // that isn't in /public (e.g. /images/foo.jpg) falls through to this page and
  // returns HTML with status 200 - which silently breaks <img> tags and makes
  // the real problem (the file is missing) very hard to spot.
  const last = segments[segments.length - 1] ?? "";
  if (last.includes(".")) notFound();

  const isRu = segments[0] === "ru";

  const t = isRu
    ? {
        badge: "Демо-сборка",
        title: "Эта страница не входит в демо",
        body: "Здесь собраны только калькулятор стоимости и AI-примерка улыбки. Остальные разделы сайта в этой сборке не участвуют - хедер и футер оставлены как на настоящем сайте, чтобы вы видели реальное оформление.",
        available: "Доступно в демо:",
        home: "На главную демо",
        items: [
          { href: "/ru/all-on-4-cost", label: "Калькулятор стоимости All-on-4 (RU)" },
          { href: "/ru/smile-preview", label: "AI-примерка улыбки (RU)" },
          { href: "/all-on-4-cost", label: "All-on-4 Cost Calculator (EN)" },
          { href: "/smile-preview", label: "AI Smile Preview (EN)" },
        ],
      }
    : {
        badge: "Review build",
        title: "This page isn't part of the demo",
        body: "This build ships only the cost calculator and the AI Smile Preview. The rest of the site isn't included - the real header and footer are kept so you can see the actual chrome, but their links land here.",
        available: "Available in this demo:",
        home: "Demo home",
        items: [
          { href: "/all-on-4-cost", label: "All-on-4 Cost Calculator (EN)" },
          { href: "/smile-preview", label: "AI Smile Preview (EN)" },
          { href: "/ru/all-on-4-cost", label: "Калькулятор стоимости All-on-4 (RU)" },
          { href: "/ru/smile-preview", label: "AI-примерка улыбки (RU)" },
        ],
      };

  return (
    <div className="mx-auto flex max-w-2xl flex-col px-4 py-24 sm:px-6 lg:px-8">
      <p className="text-sm font-bold uppercase tracking-[0.2em] text-primary">{t.badge}</p>
      <h1 className="mt-3 font-serif text-3xl font-bold tracking-tight text-neutral-900">{t.title}</h1>
      <p className="mt-2 font-mono text-sm text-neutral-400">{path}</p>
      <p className="mt-5 text-lg leading-relaxed text-neutral-600">{t.body}</p>

      <p className="mt-10 text-sm font-bold uppercase tracking-wider text-neutral-500">{t.available}</p>
      <ul className="mt-3 space-y-2">
        {t.items.map((i) => (
          <li key={i.href}>
            <Link href={i.href} className="text-primary underline decoration-primary/30 underline-offset-4 hover:decoration-primary">
              {i.label}
            </Link>
          </li>
        ))}
      </ul>

      <Link
        href="/"
        className="mt-10 inline-flex w-fit items-center rounded-full bg-primary px-6 py-3 text-sm font-bold text-white transition hover:bg-primary-dark"
      >
        {t.home}
      </Link>
    </div>
  );
}
