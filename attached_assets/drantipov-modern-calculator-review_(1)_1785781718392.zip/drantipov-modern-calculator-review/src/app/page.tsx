import Link from "next/link";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Demo build - calculator & AI Smile Preview",
  robots: { index: false, follow: false },
};

const pages = [
  {
    href: "/all-on-4-cost",
    title: "All-on-4 Cost Calculator",
    sub: "EN",
    desc: "Four treatment packages, live prices from the DentalPrice dashboard, insurance and financing steps, lead form.",
  },
  {
    href: "/ru/all-on-4-cost",
    title: "Калькулятор стоимости All-on-4",
    sub: "RU",
    desc: "Та же воронка на русском: пакеты, цены, страховка, рассрочка, заявка.",
  },
  {
    href: "/smile-preview",
    title: "AI Smile Preview",
    sub: "EN",
    desc: "Camera-based smile simulation widget plus the patient results gallery.",
  },
  {
    href: "/ru/smile-preview",
    title: "AI-примерка улыбки",
    sub: "RU",
    desc: "Тот же виджет и галерея результатов на русском.",
  },
];

export default function DemoIndex() {
  return (
    <div className="mx-auto max-w-4xl px-4 py-16 sm:px-6 lg:px-8">
      <p className="text-sm font-bold uppercase tracking-[0.2em] text-primary">Review build</p>
      <h1 className="mt-3 font-serif text-3xl font-bold tracking-tight text-neutral-900 sm:text-4xl">
        Dr. Antipov - calculator &amp; AI Smile Preview
      </h1>
      <p className="mt-4 text-lg leading-relaxed text-neutral-600">
        This is a trimmed copy of drantipov.com containing only the two pages under review.
        Prices and funnel steps are pulled live from the DentalPrice dashboard, so what you
        see here matches production.
      </p>

      <div className="mt-10 grid gap-4 sm:grid-cols-2">
        {pages.map((p) => (
          <Link
            key={p.href}
            href={p.href}
            className="group rounded-2xl border border-neutral-200 bg-white p-6 transition hover:border-primary hover:shadow-lg"
          >
            <div className="flex items-center gap-2">
              <span className="rounded-full bg-neutral-100 px-2 py-0.5 text-xs font-bold text-neutral-600">{p.sub}</span>
            </div>
            <h2 className="mt-3 font-serif text-xl font-bold text-neutral-900 group-hover:text-primary">{p.title}</h2>
            <p className="mt-2 text-sm leading-relaxed text-neutral-600">{p.desc}</p>
          </Link>
        ))}
      </div>

      <div className="mt-10 rounded-2xl border border-amber-200 bg-amber-50 p-6">
        <h2 className="font-bold text-amber-900">Notes for review</h2>
        <ul className="mt-3 space-y-2 text-sm leading-relaxed text-amber-900/90">
          <li>Only the four pages above are included. Every other link in the header and footer opens a placeholder notice.</li>
          <li>The lead form at the end of the funnel behaves exactly as it does in production.</li>
          <li>The AI Smile Preview needs camera permission and works over HTTPS or localhost.</li>
        </ul>
      </div>
    </div>
  );
}
